using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;

namespace ClassGrade
{

    public class ScoreGrade {
        public int Score { get; set; }
        public string Grade { get; set; }
    }


    public static class Function1
    {
        [FunctionName("Grade")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = null)] HttpRequest req,
            ILogger log)
        {
            int score = int.Parse(req.Query["score"]);
            log.LogInformation($"Grade: score={score}");
            if (score > 100) score = 100;
            if (score < 51) score = 51;

            var response = new ScoreGrade() {
                Score = score,
                Grade = ((char)(((100 - score) / 10) + 'A')).ToString()
            };

            return new OkObjectResult(response);
        }
    }
}

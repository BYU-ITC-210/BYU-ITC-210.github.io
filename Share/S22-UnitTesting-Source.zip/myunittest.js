let successes = 0;
let failures = 0;

async function TestGradeFromScore(score, expectedGrade) {
    const response = await fetch("http://127.0.0.1:7149/api/Grade?score=" + score);
    const res = await response.json();
    if (res.grade == expectedGrade) {
        console.log(`Success: ${res.grade} == ${expectedGrade}`);
        ++successes;
    }
    else {
        console.log(`Failure: ${res.grade} != ${expectedGrade}`);
        ++failures;
    }
}

// script.js: BYU IT&C 210a JavaScript

// Insert the Lab 1b JavaScript here.
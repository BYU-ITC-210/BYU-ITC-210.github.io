<?php
?>
<!DOCTYPE html>
<html>
<head>
    <title>Form</title>
</head>
<body>
    <h1>Form</h1>
    <form method="POST">
        <label for="statement">Statement</label>
        <input type="text" id="statement" name="statement"/>
        <input type="submit"/>
    </form>
</body>
</html>
<!DOCTYPE html>
<html>
<head>
    <title>PHP Walkthrough</title>
</head>
<body>
    <h1>Hi!</h1>
    <P> my friend!</p>
</body>
</html>

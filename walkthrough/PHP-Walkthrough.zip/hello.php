<!DOCTYPE html>
<html>
    <title>PHP Walkthrough</title>
<head>
</head>
<body>
    <h1>Hi!</h1>
    <P> my friend!</p>
</body>
</html>

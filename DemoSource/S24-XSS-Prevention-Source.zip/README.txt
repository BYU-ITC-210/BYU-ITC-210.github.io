This sample demonstrates a Cross-Site Scripting (XSS) Vulnerability and three
ways of sanitizing inputs to address the vulnerabilty. Please examine the source
of the xss.html file and read the comments in the script to understand the three
methods.
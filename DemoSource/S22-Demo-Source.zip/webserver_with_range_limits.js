// Load modules to create an http server, parse a URL and parse a URL query.
const http = require('http');
const { URL } = require('url');
const { parse: parseQuery } = require('querystring');

function ScoreServer(request, response) {
  const url = new URL(request.url, "http://localhost:8080");
  const query = parseQuery(url.search.substr(1));
  response.writeHead(200, { 'Content-Type': 'application/json' });
  let score = parseInt(query.score);
  if (score > 100) score = 100;
  if (score <= 50) score = 51;
  const grade = String.fromCharCode((100-score)/10 + 65);
  response.end(`{\n  "score": "${query.score}",\n  "grade": "${grade}"\n}\n`);
}

const server = http.createServer(ScoreServer);
server.listen(8080);
console.log(`Server running at http://localhost:8080`);
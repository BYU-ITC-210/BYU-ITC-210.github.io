// Load modules to create an http server, parse a URL and parse a URL query.
const http = require('http');
const { URL } = require('url');
const { parse: parseQuery } = require('querystring');

function ScoreServer(request, response) {
  const url = new URL(request.url, "http://localhost:8080");
  const query = parseQuery(url.search.substr(1));
  response.writeHead(200, { 'Content-Type': 'application/json' });
  const grade = String.fromCharCode((100-parseInt(query.score))/10 + 65);
  response.end(`{\n  "score": "${query.score}",\n  "grade": "${grade}"\n}\n`);
}

const server = http.createServer(ScoreServer);
server.listen(8080);
console.log(`Server running at http://localhost:8080`);
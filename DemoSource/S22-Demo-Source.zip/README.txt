This is source code for the demo used for IT&C 210B Session S22.

The server converts scores to simple letter grades. 85 = 'B', 95 = 'A', etc.

To run the server, unpack the .zip file, open a terminal and change to the
directory where you unpacked the .zip and then type "node webserver.js". You
can then call the server from a browser by browsing to
"http://localhost:8080?score=95". The response should be JSON with the score
and the grade letter.

There are two versions of the server. "webserver.js" does not do range
checking on the input score. "webserver_with_range_limits.js" does those
range checks.

The point of the demo is the unit test which is written into "unit_test.js".
Copy the contents of that file and paste it into a node console so that you
can use the function interactively. From the node console you can run tests
like:

TestGradeFromScore(85, 'B')

Even with range limits, the server has vulnerabilities. For example, it
doesn't verify that the input is a number and the JSON can be corrupted if
the input score value contains characters other than numbers.